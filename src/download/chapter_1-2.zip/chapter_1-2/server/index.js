const Koa = require('koa');
const path = require('path');
const static = require('koa-static');

const app = new Koa();

// static file
const staticPath = path.join(__dirname, 'public');
app.use(static(staticPath));

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});

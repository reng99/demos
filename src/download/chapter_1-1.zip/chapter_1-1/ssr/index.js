const Koa = require('koa');
const Router = require('koa-router');
const ejs = require('ejs');
const fs = require('fs');
const path = require('path');
const static = require('koa-static');

const app = new Koa();
const router = new Router();

// static file
const staticPath = path.join(__dirname, 'public');
app.use(static(staticPath));

// template
const template = fs.readFileSync('index.ejs', 'utf-8');

router.get('/', async (ctx) => {

  const fileName = 'test.txt';
  const fileUrl = path.join(fileName);

  // template data
  const templateData = {
    fileUrl: fileUrl
  };

  const html = await ejs.render(template, templateData);
  ctx.body = html;
});

app.use(router.routes());

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
